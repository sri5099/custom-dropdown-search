import React from "react";
import type { ViewStyle, TextStyle } from "react-native";
export interface DropdownItem {
    id?: string | number;
    value?: string | number;
    [key: string]: any;
}
export interface CustomDropDownProps {
    placeHolder?: string;
    containerStyle?: ViewStyle;
    dropDownList?: DropdownItem[];
    setState: (selected: DropdownItem | DropdownItem[]) => void;
    defaultValue?: string | number | DropdownItem[];
    disabled?: boolean;
    externalPlaceholder?: string;
    endPoint?: string;
    dropDownSearchKey: string;
    error?: string;
    multiple?: boolean;
    externalPlaceholderStyle?: TextStyle;
    externalContainerStyle?: ViewStyle;
}
declare const CustomDropDown: React.FC<CustomDropDownProps>;
export default CustomDropDown;
//# sourceMappingURL=CustomDropDown.d.ts.map