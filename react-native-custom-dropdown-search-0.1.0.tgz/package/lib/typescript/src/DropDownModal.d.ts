import React from "react";
import type { DropdownItem } from "./CustomDropDown";
export interface DropDownModalProps {
    dropDownList: DropdownItem[];
    visibility?: boolean;
    toggleVisibility?: () => void;
    onRequestClose?: () => void;
    setState: (selected: DropdownItem) => void;
    state: DropdownItem | DropdownItem[] | null;
    showSearch?: boolean;
    endPoint?: string;
    dropDownSearchKey: string;
    multiple?: boolean;
}
declare const DropDownModal: React.FC<DropDownModalProps>;
export default DropDownModal;
//# sourceMappingURL=DropDownModal.d.ts.map