export declare const SCREEN_WIDTH: number;
export declare const SCREEN_HEIGHT: number;
export declare const CHANGE_BY_MOBILE_DPI: (size: number) => number;
//# sourceMappingURL=constant.d.ts.map