import { CHANGE_BY_MOBILE_DPI } from "./constant";
export declare const Colors: {
    PRIMARY: string;
    BLACK: string;
    WHITE: string;
    TEXT_COLOR: string;
    ALERT: string;
};
export declare const Fonts: {
    REGULAR: string;
    MEDIUM: string;
    SEMIBOLD: string;
    BOLD: string;
};
export { CHANGE_BY_MOBILE_DPI };
//# sourceMappingURL=index.d.ts.map