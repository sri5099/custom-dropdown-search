import React from "react";
import type { ViewStyle, TextStyle } from "react-native";
interface CustomTextInputProps {
    value?: string;
    setValue: (text: string) => void;
    placeholderText?: string;
    searchIcon?: boolean;
    containerStyle?: ViewStyle;
    inputStyle?: TextStyle;
    autoCapitalize?: "none" | "sentences" | "words" | "characters";
}
declare const CustomTextInput: React.FC<CustomTextInputProps>;
export default CustomTextInput;
//# sourceMappingURL=CustomTextInput.d.ts.map